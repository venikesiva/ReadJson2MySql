package com.json.spring.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadJsonAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
