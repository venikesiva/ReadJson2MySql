package com.json.spring.boot.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Venike.Siva
 *
 */
@Entity
@Table(name = "outbound_bus_trans")
public class Outbound {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BUSINESS_TRANS_NUM")
    private Long id;
    
    
    @Column(name = "LAST_MODIFIED_DTM",nullable = true)
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;
    
    @Column(name = "LAST_MOD_OPER_NAM",nullable = true)
    private String lastModifiedBy;
    
    @Column(name = "BUS_TRANS_GRP_ID_NUM",nullable = true)
    private Long busTransGrpId;
    
    @Column(name = "SUBJECT_NUM",nullable = true)
    private Long subId;
    
    @Column(name = "SUBJECT_TYPE_CDE",nullable = true)
    private Long subTypeCodeId;
    
    @Column(name = "BASE_LEGAL_ENTITY_ID",nullable = true)
    private Long baseLegalEntityId;
    
    @Column(name = "ROLE_TYPE_CDE",nullable = true)
    private Long roleTypeCodeId;
    
    @Column(name = "ROLE_SEQ_NUM",nullable = true)
    private Long roleSeqId;
    
    @Column(name = "DOC_DESCR_CDE",nullable = true)
    private Long docDescrCodeId;
    
    @Column(name = "DOC_TYPE_CDE",nullable = true)
    private Long docTypeCodeId;
    
    @Column(name = "DOC_CATG_CDE",nullable = true)
    private Long docCategCodeId;
    
    @Column(name = "IMAGE_CNT",nullable = true)
    private Long imageCount;
    
    @Column(name = "COMM_DELV_MTH_CDE",nullable = true)
    private Long commDelvMthCodeId;
    
    @Column(name = "DOC_DELV_EMAIL_NAM1",nullable = true)
    private String docDelvEmailName1;
    
    @Column(name = "DOC_DELV_EMAIL_NAM2",nullable = true)
    private String docDelvEmailName2;
    
    @Column(name = "CLNT_PREF_ID_NUM",nullable = true)
    private Long clientPrefId;
    
    @Column(name = "DOC_EFFECTIVE_DTE",nullable = true)
    private String docEffDate;
    
    @Column(name = "LEGAL_ENTITY_ID",nullable = true)
    private Long legalEntityId;
    
    @Column(name = "LLEG_ENT_ID_SRC_CDE",nullable = true)
    private Long legalEntitySrcId;

    @Column(name = "SUBJ_NUM_SRC_CDE",nullable = true)
    private Long subNumSrcId;
    
    @Column(name = "DOC_INST_VIEW_CDE",nullable = true)
    private Long docInstViewId;
    
    @Column(name = "DOC_PUBLISH_IND",nullable = true)
    private String docPublishInd;
    
    @Column(name = "MERGE_GROUP_TXT",nullable = true)
    private String mergeGrpText;
    
    @Column(name = "MERGE_ID_NUM",nullable = true)
    private Long mergeId;
    
    @Column(name = "PERSON_FIRST_NAM",nullable = true)
    private String personFirstName;
    
    @Column(name = "PERSON_LAST_NAM",nullable = true)
    private String personLastName;
    
    @Column(name = "PERSON_MIDDLE_NAM",nullable = true)
    private String personMiddleName;
    
    @Column(name = "PERSONAL_NAM",nullable = true)
    private String personalName;
    
    @Column(name = "PERSONAL_SHORT_NAM",nullable = true)
    private String personShortName;
    
    @Column(name = "ADDR_LINE1_TXT",nullable = true)
    private String addrLine1;
    
    @Column(name = "ADDR_LINE2_TXT",nullable = true)
    private String addrLine2;
    
    @Column(name = "ADDR_LINE3_TXT",nullable = true)
    private String addrLine3;
    
    @Column(name = "ADDR_LINE4_TXT",nullable = true)
    private String addrLine4;
    
    @Column(name = "ADDR_LINE5_TXT",nullable = true)
    private String addrLine5;
    
    @Column(name = "FOREIGNPOSTALTXT",nullable = true)
    private String foreignPostalText;
    
    @Column(name = "FOREIGNZIPCDE",nullable = true)
    private Long foreignZipcode;
    
    @Column(name = "COUNTRY_CDE",nullable = true)
    private Long countryId;
    
    @Column(name = "FOREIGN_ADDR_IND",nullable = true)
    private String foreignAddr;
    
    @Column(name = "DOC_INST_PUBLISH_IND",nullable = true)
    private String docInstPublicInd;
    
    @Column(name = "PRD_CRT_ISSUE_STATE_CDE",nullable = true)
    private Long prdCrtIssueStateId;
    
    @Column(name = "STATE_CDE",nullable = true)
    private Long stateId;
    
    @Column(name = "ROLE_CATG_CDE",nullable = true)
    private Long roleCatgId;

    @Column(name = "CREATED_DTM",nullable = true)
    private String createdDate;
    
    @Column(name = "CREATED_BY_OPER_NAM",nullable = true)
    private String createdBy;
    
    @Column(name = "CONTENT_KEY_NUM",nullable = true)
    private Long contentKeyId;
    
    @Column(name = "ORGZTN_NAM",nullable = true)
    private String orgName;
    
    @Column(name = "DOC_DESC_TXT",nullable = true)
    private String docDesrText;
    
    @Column(name = "DOC_SUB_TYP_TXT",nullable = true)
    private String docSubTypeText;
    
    @Column(name = "SEEDING_REC_IND",nullable = true)
    private String seedingRecInd;
    
    @Column(name = "LEG_ENT_TYPE_CDE",nullable = true)
    private Long legEntTypeId;
    
    @Column(name = "DIVERT_TYPE_CDE",nullable = true)
    private Long divertTypeId;

    @Column(name = "STRG_INDX_STS_CDE",nullable = true)
    private Long strIndexStsId;
    
    @Column(name = "DISTRB_STS_CDE",nullable = true)
    private Long distrubStsId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	public Date getLastModifiedDate() {
		return new Date();
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Long getBusTransGrpId() {
		return busTransGrpId;
	}

	public void setBusTransGrpId(Long busTransGrpId) {
		this.busTransGrpId = busTransGrpId;
	}

	public Long getSubId() {
		return subId;
	}

	public void setSubId(Long subId) {
		this.subId = subId;
	}

	public Long getSubTypeCodeId() {
		return subTypeCodeId;
	}

	public void setSubTypeCodeId(Long subTypeCodeId) {
		this.subTypeCodeId = subTypeCodeId;
	}

	public Long getBaseLegalEntityId() {
		return baseLegalEntityId;
	}

	public void setBaseLegalEntityId(Long baseLegalEntityId) {
		this.baseLegalEntityId = baseLegalEntityId;
	}

	public Long getRoleTypeCodeId() {
		return roleTypeCodeId;
	}

	public void setRoleTypeCodeId(Long roleTypeCodeId) {
		this.roleTypeCodeId = roleTypeCodeId;
	}

	public Long getRoleSeqId() {
		return roleSeqId;
	}

	public void setRoleSeqId(Long roleSeqId) {
		this.roleSeqId = roleSeqId;
	}

	public Long getDocDescrCodeId() {
		return docDescrCodeId;
	}

	public void setDocDescrCodeId(Long docDescrCodeId) {
		this.docDescrCodeId = docDescrCodeId;
	}

	public Long getDocTypeCodeId() {
		return docTypeCodeId;
	}

	public void setDocTypeCodeId(Long docTypeCodeId) {
		this.docTypeCodeId = docTypeCodeId;
	}

	public Long getDocCategCodeId() {
		return docCategCodeId;
	}

	public void setDocCategCodeId(Long docCategCodeId) {
		this.docCategCodeId = docCategCodeId;
	}

	public Long getImageCount() {
		return imageCount;
	}

	public void setImageCount(Long imageCount) {
		this.imageCount = imageCount;
	}

	public Long getCommDelvMthCodeId() {
		return commDelvMthCodeId;
	}

	public void setCommDelvMthCodeId(Long commDelvMthCodeId) {
		this.commDelvMthCodeId = commDelvMthCodeId;
	}

	public String getDocDelvEmailName1() {
		return docDelvEmailName1;
	}

	public void setDocDelvEmailName1(String docDelvEmailName1) {
		this.docDelvEmailName1 = docDelvEmailName1;
	}

	public String getDocDelvEmailName2() {
		return docDelvEmailName2;
	}

	public void setDocDelvEmailName2(String docDelvEmailName2) {
		this.docDelvEmailName2 = docDelvEmailName2;
	}

	public Long getClientPrefId() {
		return clientPrefId;
	}

	public void setClientPrefId(Long clientPrefId) {
		this.clientPrefId = clientPrefId;
	}

	public String getDocEffDate() {
		return docEffDate;
	}

	public void setDocEffDate(String docEffDate) {
		this.docEffDate = docEffDate;
	}

	public Long getLegalEntityId() {
		return legalEntityId;
	}

	public void setLegalEntityId(Long legalEntityId) {
		this.legalEntityId = legalEntityId;
	}

	public Long getLegalEntitySrcId() {
		return legalEntitySrcId;
	}

	public void setLegalEntitySrcId(Long legalEntitySrcId) {
		this.legalEntitySrcId = legalEntitySrcId;
	}

	public Long getSubNumSrcId() {
		return subNumSrcId;
	}

	public void setSubNumSrcId(Long subNumSrcId) {
		this.subNumSrcId = subNumSrcId;
	}

	public Long getDocInstViewId() {
		return docInstViewId;
	}

	public void setDocInstViewId(Long docInstViewId) {
		this.docInstViewId = docInstViewId;
	}

	public String getDocPublishInd() {
		return docPublishInd;
	}

	public void setDocPublishInd(String docPublishInd) {
		this.docPublishInd = docPublishInd;
	}

	public String getMergeGrpText() {
		return mergeGrpText;
	}

	public void setMergeGrpText(String mergeGrpText) {
		this.mergeGrpText = mergeGrpText;
	}

	public Long getMergeId() {
		return mergeId;
	}

	public void setMergeId(Long mergeId) {
		this.mergeId = mergeId;
	}

	public String getPersonFirstName() {
		return personFirstName;
	}

	public void setPersonFirstName(String personFirstName) {
		this.personFirstName = personFirstName;
	}

	public String getPersonLastName() {
		return personLastName;
	}

	public void setPersonLastName(String personLastName) {
		this.personLastName = personLastName;
	}

	public String getPersonMiddleName() {
		return personMiddleName;
	}

	public void setPersonMiddleName(String personMiddleName) {
		this.personMiddleName = personMiddleName;
	}

	public String getPersonalName() {
		return personalName;
	}

	public void setPersonalName(String personalName) {
		this.personalName = personalName;
	}

	public String getPersonShortName() {
		return personShortName;
	}

	public void setPersonShortName(String personShortName) {
		this.personShortName = personShortName;
	}

	public String getAddrLine1() {
		return addrLine1;
	}

	public void setAddrLine1(String addrLine1) {
		this.addrLine1 = addrLine1;
	}

	public String getAddrLine2() {
		return addrLine2;
	}

	public void setAddrLine2(String addrLine2) {
		this.addrLine2 = addrLine2;
	}

	public String getAddrLine3() {
		return addrLine3;
	}

	public void setAddrLine3(String addrLine3) {
		this.addrLine3 = addrLine3;
	}

	public String getAddrLine4() {
		return addrLine4;
	}

	public void setAddrLine4(String addrLine4) {
		this.addrLine4 = addrLine4;
	}

	public String getAddrLine5() {
		return addrLine5;
	}

	public void setAddrLine5(String addrLine5) {
		this.addrLine5 = addrLine5;
	}

	public String getForeignPostalText() {
		return foreignPostalText;
	}

	public void setForeignPostalText(String foreignPostalText) {
		this.foreignPostalText = foreignPostalText;
	}

	public Long getForeignZipcode() {
		return foreignZipcode;
	}

	public void setForeignZipcode(Long foreignZipcode) {
		this.foreignZipcode = foreignZipcode;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getForeignAddr() {
		return foreignAddr;
	}

	public void setForeignAddr(String foreignAddr) {
		this.foreignAddr = foreignAddr;
	}

	public String getDocInstPublicInd() {
		return docInstPublicInd;
	}

	public void setDocInstPublicInd(String docInstPublicInd) {
		this.docInstPublicInd = docInstPublicInd;
	}

	public Long getPrdCrtIssueStateId() {
		return prdCrtIssueStateId;
	}

	public void setPrdCrtIssueStateId(Long prdCrtIssueStateId) {
		this.prdCrtIssueStateId = prdCrtIssueStateId;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public Long getRoleCatgId() {
		return roleCatgId;
	}

	public void setRoleCatgId(Long roleCatgId) {
		this.roleCatgId = roleCatgId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Long getContentKeyId() {
		return contentKeyId;
	}

	public void setContentKeyId(Long contentKeyId) {
		this.contentKeyId = contentKeyId;
	}

	

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getDocDesrText() {
		return docDesrText;
	}

	public void setDocDesrText(String docDesrText) {
		this.docDesrText = docDesrText;
	}

	public String getDocSubTypeText() {
		return docSubTypeText;
	}

	public void setDocSubTypeText(String docSubTypeText) {
		this.docSubTypeText = docSubTypeText;
	}

	public String getSeedingRecInd() {
		return seedingRecInd;
	}

	public void setSeedingRecInd(String seedingRecInd) {
		this.seedingRecInd = seedingRecInd;
	}

	public Long getLegEntTypeId() {
		return legEntTypeId;
	}

	public void setLegEntTypeId(Long legEntTypeId) {
		this.legEntTypeId = legEntTypeId;
	}

	public Long getDivertTypeId() {
		return divertTypeId;
	}

	public void setDivertTypeId(Long divertTypeId) {
		this.divertTypeId = divertTypeId;
	}

	public Long getStrIndexStsId() {
		return strIndexStsId;
	}

	public void setStrIndexStsId(Long strIndexStsId) {
		this.strIndexStsId = strIndexStsId;
	}

	public Long getDistrubStsId() {
		return distrubStsId;
	}

	public void setDistrubStsId(Long distrubStsId) {
		this.distrubStsId = distrubStsId;
	}
    
	/*
	 * @Column(nullable = false, updatable = false)
	 * 
	 * @Temporal(TemporalType.TIMESTAMP)
	 * 
	 * @CreatedDate private Date createdAt;
	 * 
	 * @Column(nullable = false)
	 * 
	 * @Temporal(TemporalType.TIMESTAMP)
	 * 
	 * @LastModifiedDate private Date updatedAt;
	 */

  

}
