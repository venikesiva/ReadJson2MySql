package com.json.spring.boot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.json.spring.boot.model.Outbound;


/**
 * @author Venike.Siva
 *
 */
@Repository
public interface OutboundRepository extends JpaRepository<Outbound, Long> {

}
