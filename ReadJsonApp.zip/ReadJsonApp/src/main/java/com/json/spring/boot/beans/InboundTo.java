package com.json.spring.boot.beans;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Venike.Siva
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class InboundTo {
   
	
    
    private String lastModifiedBy;
    
    private Long busTransGrpId;

    @JsonProperty("BUSINESS_TRANS_NUM") 
    private Long busTransId;
    
    private Long extBusTransId;
    
    private Long commDelveMthId;
    
    private String delvModifiedDate;
    
    private String docModifiedDate;
    
    private String bounceBackEmail1;
    
    private String docDelvEmailName2;
    
    @JsonProperty("DOC_DESCR_CDE")
    private Long docDescrId;
    
    private Long imageCount;
    
    @JsonProperty("BOUNCE_BACK_RECVD_DTM") 
    private String docReceivedDate;
    
    @JsonProperty("HOUSEHOLD_GROUP_ID")
    private String hhGrpId;
    
    @JsonProperty("ADDRESS_LINE_1_TXT")
    private String addrLine1;
    
    @JsonProperty("ADDRESS_LINE_2_TXT")
    private String addrLine2;
    
    @JsonProperty("ADDRESS_LINE_3_TXT")
    private String addrLine3;
    
    @JsonProperty("ADDRESS_LINE_4_TXT")
    private String addrLine4;
    
    @JsonProperty("ADDRESS_LINE_5_TXT")
    private String addrLine5;
   
    @JsonProperty("CLIENT_NAME")
    private String clntNameText;
    
    private String processStartDate;
    
    private String docIndexDate;
    
    private Long clientTypeId;
    
    private String mailSetIdText;
    
    private String docPrintDate;
    
    private Long printHhGrpId;
    
    private Long roleCatgId;
    
    private Long notifyDetailId;
    
    private String orgName;
    
    private Long altExtBusTransId;
    
    private Long securityGrpId;
    
    private String docEffectiveDate;
    
    private Long extSrcId;
    
    private Long subTypeId;
    @JsonProperty("SUBJECT_NUM") 
    private Long subId;
    
    private Long subNumSrcId;
    
    private Long transExceptTypeId;
    
    private Long divertTypeId;
    
    private String contentAvailInd;

	

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Long getBusTransGrpId() {
		return busTransGrpId;
	}

	public void setBusTransGrpId(Long busTransGrpId) {
		this.busTransGrpId = busTransGrpId;
	}

	public Long getBusTransId() {
		return busTransId;
	}

	public void setBusTransId(Long busTransId) {
		this.busTransId = busTransId;
	}

	public Long getExtBusTransId() {
		return extBusTransId;
	}

	public void setExtBusTransId(Long extBusTransId) {
		this.extBusTransId = extBusTransId;
	}

	public Long getCommDelveMthId() {
		return commDelveMthId;
	}

	public void setCommDelveMthId(Long commDelveMthId) {
		this.commDelveMthId = commDelveMthId;
	}

	public String getDelvModifiedDate() {
		return delvModifiedDate;
	}

	public void setDelvModifiedDate(String delvModifiedDate) {
		this.delvModifiedDate = delvModifiedDate;
	}

	public String getDocModifiedDate() {
		return docModifiedDate;
	}

	public void setDocModifiedDate(String docModifiedDate) {
		this.docModifiedDate = docModifiedDate;
	}

	public String getBounceBackEmail1() {
		return bounceBackEmail1;
	}

	public void setBounceBackEmail1(String bounceBackEmail1) {
		this.bounceBackEmail1 = bounceBackEmail1;
	}

	public String getDocDelvEmailName2() {
		return docDelvEmailName2;
	}

	public void setDocDelvEmailName2(String docDelvEmailName2) {
		this.docDelvEmailName2 = docDelvEmailName2;
	}

	public Long getDocDescrId() {
		return docDescrId;
	}

	public void setDocDescrId(Long docDescrId) {
		this.docDescrId = docDescrId;
	}

	public Long getImageCount() {
		return imageCount;
	}

	public void setImageCount(Long imageCount) {
		this.imageCount = imageCount;
	}

	public String getDocReceivedDate() {
		return docReceivedDate;
	}

	public void setDocReceivedDate(String docReceivedDate) {
		this.docReceivedDate = docReceivedDate;
	}

	
	public String getHhGrpId() {
		return hhGrpId;
	}

	public void setHhGrpId(String hhGrpId) {
		this.hhGrpId = hhGrpId;
	}

	public String getAddrLine1() {
		return addrLine1;
	}

	public void setAddrLine1(String addrLine1) {
		this.addrLine1 = addrLine1;
	}

	public String getAddrLine2() {
		return addrLine2;
	}

	public void setAddrLine2(String addrLine2) {
		this.addrLine2 = addrLine2;
	}

	public String getAddrLine3() {
		return addrLine3;
	}

	public void setAddrLine3(String addrLine3) {
		this.addrLine3 = addrLine3;
	}

	public String getAddrLine4() {
		return addrLine4;
	}

	public void setAddrLine4(String addrLine4) {
		this.addrLine4 = addrLine4;
	}

	public String getAddrLine5() {
		return addrLine5;
	}

	public void setAddrLine5(String addrLine5) {
		this.addrLine5 = addrLine5;
	}

	public String getClntNameText() {
		return clntNameText;
	}

	public void setClntNameText(String clntNameText) {
		this.clntNameText = clntNameText;
	}



	public String getProcessStartDate() {
		return processStartDate;
	}

	public void setProcessStartDate(String processStartDate) {
		this.processStartDate = processStartDate;
	}

	public String getDocIndexDate() {
		return docIndexDate;
	}

	public void setDocIndexDate(String docIndexDate) {
		this.docIndexDate = docIndexDate;
	}

	public Long getClientTypeId() {
		return clientTypeId;
	}

	public void setClientTypeId(Long clientTypeId) {
		this.clientTypeId = clientTypeId;
	}

	public String getMailSetIdText() {
		return mailSetIdText;
	}

	public void setMailSetIdText(String mailSetIdText) {
		this.mailSetIdText = mailSetIdText;
	}

	public String getDocPrintDate() {
		return docPrintDate;
	}

	public void setDocPrintDate(String docPrintDate) {
		this.docPrintDate = docPrintDate;
	}

	public Long getPrintHhGrpId() {
		return printHhGrpId;
	}

	public void setPrintHhGrpId(Long printHhGrpId) {
		this.printHhGrpId = printHhGrpId;
	}

	public Long getRoleCatgId() {
		return roleCatgId;
	}

	public void setRoleCatgId(Long roleCatgId) {
		this.roleCatgId = roleCatgId;
	}

	public Long getNotifyDetailId() {
		return notifyDetailId;
	}

	public void setNotifyDetailId(Long notifyDetailId) {
		this.notifyDetailId = notifyDetailId;
	}


	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public Long getAltExtBusTransId() {
		return altExtBusTransId;
	}

	public void setAltExtBusTransId(Long altExtBusTransId) {
		this.altExtBusTransId = altExtBusTransId;
	}

	public Long getSecurityGrpId() {
		return securityGrpId;
	}

	public void setSecurityGrpId(Long securityGrpId) {
		this.securityGrpId = securityGrpId;
	}

	public String getDocEffectiveDate() {
		return docEffectiveDate;
	}

	public void setDocEffectiveDate(String docEffectiveDate) {
		this.docEffectiveDate = docEffectiveDate;
	}

	public Long getExtSrcId() {
		return extSrcId;
	}

	public void setExtSrcId(Long extSrcId) {
		this.extSrcId = extSrcId;
	}

	public Long getSubTypeId() {
		return subTypeId;
	}

	public void setSubTypeId(Long subTypeId) {
		this.subTypeId = subTypeId;
	}

	public Long getSubId() {
		return subId;
	}

	public void setSubId(Long subId) {
		this.subId = subId;
	}

	public Long getSubNumSrcId() {
		return subNumSrcId;
	}

	public void setSubNumSrcId(Long subNumSrcId) {
		this.subNumSrcId = subNumSrcId;
	}

	public Long getTransExceptTypeId() {
		return transExceptTypeId;
	}

	public void setTransExceptTypeId(Long transExceptTypeId) {
		this.transExceptTypeId = transExceptTypeId;
	}

	public Long getDivertTypeId() {
		return divertTypeId;
	}

	public void setDivertTypeId(Long divertTypeId) {
		this.divertTypeId = divertTypeId;
	}

	public String getContentAvailInd() {
		return contentAvailInd;
	}

	public void setContentAvailInd(String contentAvailInd) {
		this.contentAvailInd = contentAvailInd;
	}
    
    
    
}
