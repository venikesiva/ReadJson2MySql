package com.json.spring.boot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.json.spring.boot.exception.ResourceNotFoundException;
import com.json.spring.boot.model.Inbound;
import com.json.spring.boot.repository.InboundRepository;


/**
 * @author Venike.Siva
 *
 */
@RestController
@RequestMapping("/api")
public class InboundController {

    @Autowired
    InboundRepository inboundRepository;

    @GetMapping("/inbounds")
    public List<Inbound> getAllInbounds() {
        return inboundRepository.findAll();
    }

    @PostMapping("/inbound")
    public Inbound createInbound(@Valid @RequestBody Inbound inbound) {
        return inboundRepository.save(inbound);
    }

    @GetMapping("/inbound/{id}")
    public Inbound getInboundById(@PathVariable(value = "id") Long inboundId) {
        return inboundRepository.findById(inboundId)
                .orElseThrow(() -> new ResourceNotFoundException("Inbound", "id", inboundId));
    }

    @PutMapping("/inbound/{id}")
    public Inbound updateInbound(@PathVariable(value = "id") Long inboundId,
                                           @Valid @RequestBody Inbound inboundDetails) {

        Inbound inbound = inboundRepository.findById(inboundId)
                .orElseThrow(() -> new ResourceNotFoundException("Inbound", "id", inboundId));

        Inbound updatedInbound = inboundRepository.save(inbound);
        return updatedInbound;
    }

    @DeleteMapping("/inbound/{id}")
    public ResponseEntity<?> deleteInbound(@PathVariable(value = "id") Long inboundId) {
        Inbound inbound = inboundRepository.findById(inboundId)
                .orElseThrow(() -> new ResourceNotFoundException("Inbound", "id", inboundId));

        inboundRepository.delete(inbound);

        return ResponseEntity.ok().build();
    }
}
