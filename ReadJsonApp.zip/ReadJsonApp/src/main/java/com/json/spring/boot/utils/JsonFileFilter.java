package com.json.spring.boot.utils;

import java.io.File;
import java.io.FilenameFilter;

public class JsonFileFilter implements FilenameFilter{

	 @Override
     public boolean accept(File dir, String name) {
         if(name.toLowerCase().endsWith(".json")){
             return true;
         } else {
             return false;
         }
     }

}
