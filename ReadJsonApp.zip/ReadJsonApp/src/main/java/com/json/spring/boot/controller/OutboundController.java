package com.json.spring.boot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.json.spring.boot.exception.ResourceNotFoundException;
import com.json.spring.boot.model.Outbound;
import com.json.spring.boot.repository.OutboundRepository;


/**
 * @author Venike.Siva
 *
 */
@RestController
@RequestMapping("/api")
public class OutboundController {

    @Autowired
    OutboundRepository outboundRepository;

    @GetMapping("/outbounds")
    public List<Outbound> getAllOutbounds() {
        return outboundRepository.findAll();
    }

    @PostMapping("/outbound")
    public Outbound createOutbound(@Valid @RequestBody Outbound outbound) {
        return outboundRepository.save(outbound);
    }

    @GetMapping("/outbound/{id}")
    public Outbound getOutboundById(@PathVariable(value = "id") Long outboundId) {
        return outboundRepository.findById(outboundId)
                .orElseThrow(() -> new ResourceNotFoundException("Outbound", "id", outboundId));
    }

    @PutMapping("/outbound/{id}")
    public Outbound updateOutbound(@PathVariable(value = "id") Long outboundId,
                                           @Valid @RequestBody Outbound outboundDetails) {

        Outbound outbound = outboundRepository.findById(outboundId)
                .orElseThrow(() -> new ResourceNotFoundException("Outbound", "id", outboundId));

        Outbound updatedOutbound = outboundRepository.save(outbound);
        return updatedOutbound;
    }

    @DeleteMapping("/outbound/{id}")
    public ResponseEntity<?> deleteOutbound(@PathVariable(value = "id") Long outboundId) {
        Outbound outbound = outboundRepository.findById(outboundId)
                .orElseThrow(() -> new ResourceNotFoundException("Outbound", "id", outboundId));

        outboundRepository.delete(outbound);

        return ResponseEntity.ok().build();
    }
}
