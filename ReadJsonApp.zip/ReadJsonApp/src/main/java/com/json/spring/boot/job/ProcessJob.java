package com.json.spring.boot.job;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.spring.boot.beans.InboundTo;
import com.json.spring.boot.model.Inbound;
import com.json.spring.boot.model.Outbound;
import com.json.spring.boot.utils.JsonFileFilter;
@Component
@Configuration
@PropertySource(ignoreResourceNotFound = true, value = "classpath:application.properties")
public class ProcessJob {

	@Value("${json.filepath}")
	private String filePath;
	 @Scheduled(cron = "${cron.expression}")
    public void demoServiceMethod() throws JsonParseException, JsonMappingException, IOException
	{
		System.out.println("This process will run based on the cron expression. Current time is :: " + new Date());

		System.out.println("Json File processing is started");
		System.out.println("Files will be considered from the path "+filePath);
		try {
			RestTemplate template = new RestTemplate();

			Inbound inbound = new Inbound();
			System.out.println(filePath);
			ObjectMapper objectMapper = new ObjectMapper();

			File file = new File(filePath);
			
			String[] files = file.list(new JsonFileFilter());
			if(files!=null && files.length>0) {
			for (String fileName : files) {
			// read json file and convert to customer object
			InboundTo itoObjes[] = objectMapper.readValue(new File(filePath+"//"+fileName),
					InboundTo[].class);
			for(int index = 0;index<itoObjes.length;index++) {
				InboundTo ito = itoObjes[index];
				ResponseEntity<Outbound> outboundRes = template.getForEntity("http://localhost:8080/api/outbound/"+ito.getBusTransId(), Outbound.class);
				Outbound ob = outboundRes.getBody();
				ito.setBusTransId(ob.getId());
				ito.setBusTransGrpId(ob.getBusTransGrpId()!=null?ob.getBusTransGrpId():null);
				ito.setCommDelveMthId(ob.getCommDelvMthCodeId()!=null?ob.getCommDelvMthCodeId():null);
				ito.setDocDelvEmailName2(ob.getDocDelvEmailName2()!=null?ob.getDocDelvEmailName2():null);
				ito.setDocDescrId(ob.getDocDescrCodeId()!=null?ob.getDocDescrCodeId():null);
				ito.setImageCount(ob.getImageCount()!=null?ob.getImageCount():null);
				ito.setRoleCatgId(ob.getRoleCatgId()!=null?ob.getRoleCatgId():null);
				ito.setOrgName(ob.getOrgName()!=null?ob.getOrgName():null);
				ito.setDocEffectiveDate(ob.getDocEffDate()!=null?ob.getDocEffDate():null);
				ito.setSubTypeId(ob.getSubTypeCodeId()!=null?ob.getSubTypeCodeId():null);
				ito.setSubId(ob.getSubId()!=null?ob.getSubId():null);
				ito.setSubNumSrcId(ob.getSubNumSrcId()!=null?ob.getSubNumSrcId():null);
				ito.setDivertTypeId(ob.getDivertTypeId()!=null?ob.getDivertTypeId():null);
				
				BeanUtils.copyProperties(ito, inbound, getNullPropertyNames(ito));
	
				
				ResponseEntity<Inbound> res = template.postForEntity("http://localhost:8080/api/inbound", inbound,
						Inbound.class);
	
				Inbound obj = res.getBody();
	
				System.out.println(obj.getId());
			}
			}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	 
	 public static String[] getNullPropertyNames (Object source) {
    	if(source!=null){
	        final BeanWrapper src = new BeanWrapperImpl(source);
	        java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();
	
	        Set<String> emptyNames = new HashSet<String>();
	        for(java.beans.PropertyDescriptor pd : pds) {
	            Object srcValue = src.getPropertyValue(pd.getName());
	            if (srcValue == null || "".equals(srcValue)) emptyNames.add(pd.getName());
	        }
	        String[] result = new String[emptyNames.size()];
	        return emptyNames.toArray(result);
    	}else{
    		return new String[0];
    	}
	  }
	 
	 @Bean
	    public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
	        return new PropertySourcesPlaceholderConfigurer();
	    }
}
